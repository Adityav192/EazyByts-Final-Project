Event Management Fullstack Project
=================================
This zip contains two folders: backend and frontend.
Follow the README files inside each folder to run the app locally.

Features included:
  - User registration & login (JWT)
  - Event listing & details
  - Booking creation & user bookings list
  - Admin-protected event CRUD endpoints (requires manually setting role in DB)
  - Minimal React frontend pages for core flows