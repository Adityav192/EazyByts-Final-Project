Backend for Event Management
----------------------------

Setup:
  1. Copy .env.example to .env and set values (MONGO_URI, JWT_SECRET)
  2. npm install
  3. npm run dev (requires nodemon) or npm start

Endpoints:
  POST /api/auth/register
  POST /api/auth/login
  GET  /api/events
  GET  /api/events/:id
  POST /api/events   (admin)
  PUT  /api/events/:id (admin)
  DELETE /api/events/:id (admin)
  POST /api/bookings
  GET  /api/bookings/me