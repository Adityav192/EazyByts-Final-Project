const express = require('express');
const Booking = require('../models/Booking');
const Event = require('../models/Event');
const auth = require('../middleware/auth');
const router = express.Router();

router.post('/', auth, async (req,res) => {
  try{
    const { eventId, seats } = req.body;
    const ev = await Event.findById(eventId);
    if(!ev) return res.status(404).json({ message: 'Event not found' });
    // Simplified payment placeholder -- in production integrate a payments provider
    const amount = (ev.price || 0) * (seats || 1);
    const booking = new Booking({ event: ev._id, user: req.user._id, seats, amountPaid: amount, status: 'confirmed' });
    await booking.save();
    res.json(booking);
  }catch(err){
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/me', auth, async (req,res) => {
  const bookings = await Booking.find({ user: req.user._id }).populate('event');
  res.json(bookings);
});

module.exports = router;