const express = require('express');
const Event = require('../models/Event');
const auth = require('../middleware/auth');
const router = express.Router();

// List events with optional query filters
router.get('/', async (req,res) => {
  const { q, tag, upcoming } = req.query;
  const filter = {};
  if(q) filter.title = { $regex: q, $options: 'i' };
  if(tag) filter.tags = tag;
  if(upcoming === 'true') filter.date = { $gte: new Date() };
  const events = await Event.find(filter).sort({ date: 1 });
  res.json(events);
});

router.get('/:id', async (req,res) => {
  const ev = await Event.findById(req.params.id);
  if(!ev) return res.status(404).json({ message: 'Event not found' });
  res.json(ev);
});

// Admin create event (protected)
router.post('/', auth, async (req,res) => {
  if(req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden' });
  const ev = new Event(req.body);
  await ev.save();
  res.json(ev);
});

// Update and delete for admin
router.put('/:id', auth, async (req,res) => {
  if(req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden' });
  const ev = await Event.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(ev);
});

router.delete('/:id', auth, async (req,res) => {
  if(req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden' });
  await Event.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;