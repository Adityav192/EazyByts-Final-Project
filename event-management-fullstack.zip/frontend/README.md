Frontend for Event Management
----------------------------

Setup:
  1. npm install
  2. npm start

Notes:
  - The frontend expects the backend to run on http://localhost:5000 by default.
  - Update API_BASE in src/services/api.js if backend runs elsewhere.