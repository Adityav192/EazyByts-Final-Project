import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Events from './pages/Events';
import EventDetail from './pages/EventDetail';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';

function App(){
  return (
    <div>
      <nav style={{ padding: 16, borderBottom: '1px solid #ddd' }}>
        <Link to='/' style={{ marginRight: 12 }}>Events</Link>
        <Link to='/dashboard' style={{ marginRight: 12 }}>Dashboard</Link>
        <Link to='/login'>Login</Link>
      </nav>
      <main style={{ padding: 16 }}>
        <Routes>
          <Route path='/' element={<Events/>} />
          <Route path='/events/:id' element={<EventDetail/>} />
          <Route path='/login' element={<Login/>} />
          <Route path='/register' element={<Register/>} />
          <Route path='/dashboard' element={<Dashboard/>} />
        </Routes>
      </main>
    </div>
  );
}

export default App;