import React, { useEffect, useState } from 'react';
import api, { setAuthToken } from '../services/api';

export default function Dashboard(){
  const [bookings, setBookings] = useState([]);
  useEffect(()=>{
    const token = localStorage.getItem('token');
    if(token){
      setAuthToken(token);
      api.get('/bookings/me').then(r=> setBookings(r.data)).catch(console.error);
    }
  },[]);
  return (
    <div>
      <h2>Your Bookings</h2>
      {bookings.length===0 && <p>No bookings yet.</p>}
      <ul>
        {bookings.map(b=> (
          <li key={b._id}>
            <strong>{b.event.title}</strong> - {b.seats} seat(s) - {b.status}
          </li>
        ))}
      </ul>
    </div>
  );
}