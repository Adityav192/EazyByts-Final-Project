import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api, { setAuthToken } from '../services/api';

export default function EventDetail(){
  const { id } = useParams();
  const [ev, setEv] = useState(null);
  useEffect(()=>{
    api.get('/events/' + id).then(r=> setEv(r.data)).catch(console.error);
  },[id]);
  const book = async ()=>{
    const token = localStorage.getItem('token');
    if(!token) return alert('Please login first');
    setAuthToken(token);
    try{
      const res = await api.post('/bookings', { eventId: id, seats: 1 });
      alert('Booked! Booking id: ' + res.data._id);
    }catch(err){
      console.error(err);
      alert('Booking failed');
    }
  };
  if(!ev) return <div>Loading...</div>;
  return (
    <div>
      <h2>{ev.title}</h2>
      <div>{new Date(ev.date).toLocaleString()}</div>
      <p>{ev.description}</p>
      <div>Price: ₹{ev.price || 0}</div>
      <button onClick={book}>Book 1 ticket</button>
    </div>
  );
}