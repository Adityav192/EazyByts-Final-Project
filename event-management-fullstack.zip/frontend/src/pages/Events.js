import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { Link } from 'react-router-dom';

export default function Events(){
  const [events, setEvents] = useState([]);
  useEffect(()=>{
    api.get('/events').then(res => setEvents(res.data)).catch(console.error);
  },[]);
  return (
    <div>
      <h2>Events</h2>
      {events.length===0 && <p>No events found.</p>}
      <ul>
        {events.map(ev=>(
          <li key={ev._id} style={{ marginBottom: 12 }}>
            <Link to={'/events/' + ev._id}><strong>{ev.title}</strong></Link>
            <div>{new Date(ev.date).toLocaleString()} - {ev.location}</div>
            <div>Price: ₹{ev.price || 0}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}